Change your password <a href="http://localhost:8000">here</a>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ApiGatewayContainer/resources/views/Mails/forgot.blade.php ENDPATH**/ ?>